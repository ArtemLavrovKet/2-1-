﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array65
{
    internal class Program
    {
        static void Main(string[] args)
        //Array65. Дан массив A размера N и целое число K (1 ≤ K ≤ N).
        //Преобразовать массив, увеличив каждый его элемент на исходное значение элемента AK.
        {
            Console.WriteLine("введите размер массива");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("введите число k");
            int k = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            int[] b = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("введите элемент массива");
                a[i] = int.Parse(Console.ReadLine());
                b[i] = a[i] + k;
            }
            Console.WriteLine($"получившийся массив");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(b[i]);
            }
            Console.ReadKey();
        }
    }
}
