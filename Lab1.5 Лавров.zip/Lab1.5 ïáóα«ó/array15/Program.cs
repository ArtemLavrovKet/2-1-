﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array15
{
    internal class Program
    {
        static void Main(string[] args)
        //Array15. Дан массив A размера N. Вывести вначале его элементы с нечетными номерами в порядке возрастания номеров,
        //а затем — элементы с четными номерами в порядке убывания номеров:A1,    A3,    A5,    …,    A6,    A4,    A2. Условный оператор не использовать.
        {
            Console.Write("Введите размер массива: ");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            for (int i = 0; i < n; i += 1)
            {
                Console.WriteLine("введите элемент массива");
                a[i] = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine($"a[{i}]" + a[i]);
            }
            Console.WriteLine("вывод");
            for (int i = 1; i <= n; i += 2)
            {
                Console.WriteLine($"a[{i}] = {a[i - 1]}");
            }
            for (int i = n; i > 0; i -= 2)
            {
                Console.WriteLine($"a[{i}] = {a[i - 1]}");
            }
            Console.ReadKey();
        }
    }
}
