﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arrey19
{
    internal class Program
    {
        static void Main(string[] args)
        //Array19. Дан целочисленный массив A размера 10.
        //Вывести порядковый номер последнего из тех его элементов AK, которые удовлетворяют двойному неравенству A1 < AK < A10.
        //Если таких элементов нет, то вывести 0.
        {
            int n = 10;
            int b = 0;
            int c = 0;
            int[] a = new int[n];
            for (int i = 0; i < n; i += 1)
            {
                Console.WriteLine("введите элемент массива");
                a[i] = Convert.ToInt16(Console.ReadLine());
                if (i==1)
                {
                    c = a[i];
                }
                if (i==10)
                {
                    b = a[i];
                }
                Console.WriteLine($"a[{i}]" + a[i]);
            }
            for (int i = 0; i < n; i++)
            {
                if (c < a[i] && a[i] < b)
                {
                    Console.WriteLine($"значение равно " + i);
                }
                else
                {
                    Console.WriteLine(0);
                }
            }
            Console.ReadKey();
        }
    }
}
