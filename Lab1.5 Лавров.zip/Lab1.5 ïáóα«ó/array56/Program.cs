﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array56
{
    internal class Program
    {
        static void Main(string[] args)
        //Array56. Дан целочисленный массив A размера N (≤ 15).
        //Переписать в новый целочисленный массив B все элементы с порядковыми номерами, кратными трем (3, 6, …),
        //и вывести размер полученного массива B и его содержимое. Условный оператор не использовать.
        {
            Random Rand = new Random();
            Console.WriteLine("размер массивов");
            int n = 15;
            int[] a = new int[n];
            int[] b = new int[n];
            int k = 0;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Введите элемент первого массива");
                a[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                b[i] = 3 * a[i];
                k++;
                Console.WriteLine($"Элемнты кратные 3\t" + b[i]);
            }
            Console.WriteLine($"Размер массива равен\t" + k);
            Console.ReadKey();
        }
    }
}
