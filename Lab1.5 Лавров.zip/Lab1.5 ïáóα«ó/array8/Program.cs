﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array8
{
    internal class Program
    {
        static void Main(string[] args)
        //Array8. Дан целочисленный массив размера N.
        //Вывести все содержащиеся в данном массиве нечетные числа в порядке возрастания их индексов, а также их количество K.
        {
            int n = int.Parse(Console.ReadLine());
            int[] d = new int[n];
            int k = 0;
            for (int i = 0; i < n; i++)
            {
                d[i] = 1 + i * 2;
                k++;
                Console.WriteLine(d[i]);
            }
            Console.WriteLine($"кол-во чисел {k}");
            Console.ReadKey();
        }
    }
}
