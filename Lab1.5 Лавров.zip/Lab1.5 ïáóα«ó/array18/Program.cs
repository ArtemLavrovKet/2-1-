﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array18
{
    internal class Program
    {
        static void Main(string[] args)
        //rray18. Дан массив A ненулевых целых чисел размера 10.
        //Вывести значение первого из тех его элементов AK, которые удовлетворяют неравенству AK < A10.
        //Если таких элементов нет, то вывести 0.
        {
            int n = 10;
            int b = 0;
            int[] a = new int[n];
            for (int i = 0; i < n; i += 1)
            {
                Console.WriteLine("введите элемент массива");
                a[i] = Convert.ToInt16(Console.ReadLine());
                b = a[i];
                Console.WriteLine($"a[{i}]" + a[i]);
            }
            for (int i = 0; i <n; i++)
            {
                if (a[i]<b)
                {
                    Console.WriteLine($"значение равно" + a[i]);
                }
                else
                {
                    Console.WriteLine(0);
                }
            }
            Console.ReadKey();
        }
    }
}
