﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array57
{
    internal class Program
    {
        static void Main(string[] args)
        //Array57. Дан целочисленный массив A размера N.
        //Переписать в новый целочисленный массив B того же размера вначале все элементы исходного массива с четными номерами,
        //а затем — с нечетными:
        //A2,    A4,    A6,    …,    A1,    A3,    A5,    … .
        //Условный оператор не использовать.
        {
            Console.WriteLine("введите размер массива ");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            int[] b = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("введите элементы массива ");
                a[i] = int.Parse(Console.ReadLine());
            }
            int i2 = 0;
            for (int i = 1; i <= n; i = i + 2)
            {
                i2++;
                b[i2] = a[i];

            }
            for (int i = 2; i < n; i = i + 2)
            {
                i2++;
                b[i2] = a[i];
            }
            for (int i = 1; i < n; i++)
            {
                Console.WriteLine(b[i]);
            }
            Console.ReadKey();
        }
    }
}
