﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array7
{
    internal class Program
    {
        static void Main(string[] args)
        //Array7°. Дан массив размера N. Вывести его элементы в обратном порядке.
        {
            int n = int.Parse(Console.ReadLine());
            int[] k = new int[n];
            for (int i = n-1; i >= 0; i--)
            {
                k[i] = i;
                Console.WriteLine(k[i]);
            }
            Console.ReadKey();
        }
    }
}
