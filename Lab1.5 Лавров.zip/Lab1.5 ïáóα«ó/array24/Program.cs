﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array24
{
    internal class Program
    {
        static void Main(string[] args)
        //Array24. Дан целочисленный массив размера N, не содержащий одинаковых чисел.
        //Проверить, образуют ли его элементы арифметическую прогрессию (см. задание Array3).
        //Если образуют, то вывести разность прогрессии, если нет — вывести 0.
        {
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
            {
                a[i] = int.Parse(Console.ReadLine());
            }
            int b = a[1] - a[0];
            for (int i = 1; i < n; i++)
            {
                if (b != a[i] - a[i - 1])
                {
                    b = 0;
                }
            }
            Console.WriteLine(b);
            Console.ReadKey();
        }
    }
}
