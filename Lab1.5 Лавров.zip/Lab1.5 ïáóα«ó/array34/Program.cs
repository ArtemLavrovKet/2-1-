﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array51
{
    internal class Program
    {
        static void Main(string[] args)
        //Array51. Даны массивы A и B одинакового размера N.
        //Поменять местами их содержимое и вывести вначале элементы преобразованного массива A,
        //а затем — элементы преобразованного массива B.
        {
            Console.WriteLine("введите размер массивов");
            int n = int.Parse(Console.ReadLine());
            int[] A = new int[n];
            int[] B = new int[n];
            int a = 0;
            int b = 0;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Введите элемент первого массива");
                A[i] = int.Parse(Console.ReadLine());

            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Введите элемент второго массива");
                B[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                a= A[i];
                b = B[i];
                A[i] = a;
                B[i] = b;
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Элемент изменённого массива А {A[i]}");
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Элемент изменённого массива B {B[i]}");
            }
            Console.ReadKey();
        }
    }
}
