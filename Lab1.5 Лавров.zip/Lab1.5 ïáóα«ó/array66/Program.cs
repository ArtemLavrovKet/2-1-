﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array66
{
    internal class Program
    {
        static void Main(string[] args)
        //Array66. Дан целочисленный массив размера N. Увеличить все четные числа, содержащиеся в массиве,
        //на исходное значение первого четного числа.
        //Если четные числа в массиве отсутствуют, то оставить массив без изменений.
        {
            Console.WriteLine("введите размер массива");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            int b = 0;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("введите элемент массива");
                a[i] = int.Parse(Console.ReadLine());
                if (i == 0)
                {
                    b = a[i];
                }
                if (a[i] % 2 == 0)
                {
                    a[i] = a[i] + b;
                }
            }
            Console.WriteLine("получившийся массив");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(a[i]);
            }
            Console.ReadKey();
        }
    }
}
