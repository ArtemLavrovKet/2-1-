﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array52
{
    internal class Program
    {
        static void Main(string[] args)
            //Array52. Дан массив A размера N. Сформировать новый массив B того же размера,
            //элементы которого определяются следующим образом: (А-к-атое попалам)
        {
            Console.WriteLine("введите размер массивов");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            int[] b = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Введите элемент первого массива");
                a[i] = int.Parse(Console.ReadLine());

            }
            for (int i = 0; i < n; i++)
            {
                if (a[i] < 5)
                {
                    b[i] = 2 * a[i];
                    Console.WriteLine($"Элементы масиива b равны:"+ b[i]);
                }
                else
                {
                    b[i] = a[i] / 2;
                    Console.WriteLine($"Элементы масиива b равны:" + b[i]);
                }
            }
            Console.ReadKey();
        }
    }
}
