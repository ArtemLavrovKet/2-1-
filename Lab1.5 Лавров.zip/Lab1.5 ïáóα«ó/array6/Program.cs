﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array6
{
    internal class Program
    {
        static void Main(string[] args)
        //Array6. Даны целые числа N (> 2), A и B. Сформировать и вывести целочисленный массив размера N,
        //первый элемент которого равен A, второй равен B, а каждый последующий элемент равен сумме всех предыдущих.
        {
            int n = int.Parse(Console.ReadLine());
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int d = 0;
            int[] c = new int[n];
            c[0] = a;
            c[1] = b;
            d = c[0] + c[1];
            for (int i = 2; i < n; i++)
            {
                c[i] = d;
                d = c[i] + d;
                Console.WriteLine(c[i]);
            }
            Console.ReadKey();
        }
    }
}
