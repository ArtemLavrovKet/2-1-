﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab1_5
{
    internal class Program
    {
        static void Main(string[] args)
        //Array1. Дано целое число N (> 0).
        //Сформировать и вывести целочисленный массив размера N, содержащий N первых положительных нечетных чисел: 1, 3, 5, … .
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
                a[i] = 1 + i * 2;
            for (int i = 0; i < n; i++)
                Console.WriteLine(a[i]);
            Console.ReadKey();
        }
    }
}
