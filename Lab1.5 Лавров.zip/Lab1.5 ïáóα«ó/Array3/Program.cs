﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array3
{
    internal class Program
    {
        static void Main(string[] args)
            //Array3. Дано целое число N (> 1), а также первый член A и разность D арифметической прогрессии.
            //Сформировать и вывести массив размера N, содержащий N первых членов данной прогрессии:A, A + D, A + 2·D, A + 3·D,  … .
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int a = Convert.ToInt32(Console.ReadLine());
            int d = Convert.ToInt32(Console.ReadLine());
            int[] e = new int[n];
            for (int i = 0; i < n; i++)
            {
                e[i] = a + i * d;
                Console.WriteLine(e[i]);
            }
            Console.ReadKey();
        }
    }
}
